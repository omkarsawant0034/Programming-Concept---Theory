#include<stdio.h>

int main()
{
    // Loop Counter
    int i = 0;

    //    1        2       3
    for( i = 1;  i <= 5;  i++)
    {
        printf("Jay Ganesh...\n");  // 4
    }

    return 0;
}